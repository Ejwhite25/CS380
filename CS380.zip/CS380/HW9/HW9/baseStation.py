import serial
import signal
import time
import csv
import sys

# /dev/cu.usbserial-D308FBLO
# /dev/cu.usbserial-D308GBYP


s = serial.Serial(sys.argv[1], 57600)
read = True


def stopSampling(signum, frame):
    file.close()
    read = False
    stopInput = 'S'
    stopCommand = bytes(stopInput.encode())
    try:
        s.write(stopCommand)
        s.flushOutput()
        s.close()
        exit(0)
    except Exception as e:
        print("Failed to write stop command to serial")
        print(e)
        exit(1)


def main():
    global file
    timeStamp = time.strftime("%m_%d_%Y_%I_%M_%S", time.localtime())
    signal.signal(signal.SIGINT, stopSampling)
    if len(sys.argv[1]) == 0:
        print("Need argument for usb port")
        exit(1)
    if not s.isOpen():
        print("Serial port failed to open")
        exit(1)
    startInput = 'R'
    startCommand = bytes(startInput.encode())
    try:
        s.write(startCommand)
        s.flushOutput()
    except Exception as e:
        print("Failed to write to serial")
        print(e)
        exit(1)
    while read:
        try:
            serialData = s.readline()
        except Exception as e:
            print("Failed to read data from serial")
            print(e)
            exit(1)
        decodedData = int(serialData.decode())
        print(decodedData)
        row = [decodedData,decodedData,decodedData]
        file = open(timeStamp + '.csv', 'a')
        writer = csv.writer(file, delimiter=',')
        writer.writerow(row)


if __name__ == "__main__":
    main()
