import serial
import signal
import time
import csv
import sys
from threading import Timer
import threading

# /dev/cu.usbserial-D308FBLO


s = serial.Serial("/dev/cu.usbserial-D308FBLO", 57600)
read = True


def shutoffTrashCan(signum, frame):
    global read
    read = False
    stopInput = 'C'
    stopCommand = bytes(stopInput.encode())
    try:
        s.write(stopCommand)
        s.flushOutput()
        s.close()
        exit(0)
    except Exception as e:
        print("Failed to write stop command to serial")
        print(e)
        exit(1)


def main():
    global serialData
    signal.signal(signal.SIGINT, shutoffTrashCan)
    if len(sys.argv[1]) == 0:
        print("Need argument for usb port")
        exit(1)
    if not s.isOpen():
        print("Serial port failed to open")
        exit(1)
    startInput = 'O'
    startCommand = bytes(startInput.encode())
    try:
        s.write(startCommand)
        s.flushOutput()
    except Exception as e:
        print("Failed to write start command to serial")
        print(e)
        exit(1)
    timeStamp = time.strftime("%m_%d_%Y_%I_%M_%S", time.localtime())
    while read:
        if s.isOpen():
            try:
                serialData = s.readline()
            except Exception as e:
                print("Failed to read data from serial")
                print(e)
                exit(1)
        decodedData = serialData.decode()
        decodedData = decodedData.strip()
        print(decodedData)
        csvTimeStamp = time.strftime("%m_%d_%Y_%I_%M_%S", time.localtime())
        row = [decodedData, csvTimeStamp]
        file = open(timeStamp + '.csv', 'a')
        writer = csv.writer(file, delimiter=',')
        writer.writerow(row)


if __name__ == "__main__":
    main()
