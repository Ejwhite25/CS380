import serial
import signal
import time
import csv
import sys
from threading import Timer
import threading

# /dev/cu.usbserial-D308FBLO
# /dev/cu.usbserial-D308GBYP


s = serial.Serial(sys.argv[1], int(sys.argv[2]))
syncInterval = float(sys.argv[3]) / 1000
read = True
keepSync = True
stop = False


def stopSampling(signum, frame):
    stopInput = 'T'
    stopCommand = bytes(stopInput.encode())
    try:
        s.write(stopCommand)
        s.flushOutput()
        time.sleep(1)
        global read
        read = False
        global keepSync
        keepSync = False
        global stop
        stop = True
        s.close()
        exit(0)
    except Exception as e:
        print("Failed to write stop command to serial")
        print(e)
        exit(1)


def main():
    global readThread
    global syncThread
    readThread = threading.Thread(target=readData)
    syncThread = threading.Thread(target=sync)
    signal.signal(signal.SIGINT, stopSampling)
    if len(sys.argv[1]) == 0:
        print("Need argument for usb port")
        exit(1)
    elif len(sys.argv[2]) == 0:
        print("Need baud rate argument")
        exit(1)
    elif len(sys.argv[3]) == 0:
        print("Need sync rate argument")
        exit(1)
    if not s.isOpen():
        print("Serial port failed to open")
        exit(1)
    time.sleep(2)
    startInput = 'R'
    startCommand = bytes(startInput.encode())
    try:
        s.write(startCommand)
        s.flushOutput()
    except Exception as e:
        print("Failed to write start command to serial")
        print(e)
        exit(1)
    readThread.start()
    syncThread.start()
    readThread.join()
    syncThread.join()


def sync():
    while keepSync:
        time.sleep(syncInterval)
        syncInput = 'S'
        syncCommand = bytes(syncInput.encode())
        if s.isOpen():
            try:
                s.write(syncCommand)
                s.flushOutput()
                print("Synchronized sent")
            except Exception as e:
                print("Failed to write sync command to serial")
                print(e)
                exit(1)
    return


def readData():
    global serialData
    timeStamp = time.strftime("%m_%d_%Y_%I_%M_%S", time.localtime())
    while read:
        if s.isOpen():
            try:
                serialData = s.readline()
            except Exception as e:
                if stop:
                    return
                print("Failed to read data from serial")
                print(e)
                exit(1)
        decodedData = serialData.decode()
        decodedData = decodedData.strip()
        print(decodedData)
        row = [decodedData]
        file = open(timeStamp + '.csv', 'a')
        writer = csv.writer(file,delimiter=',')
        writer.writerow(row)
    return


if __name__ == "__main__":
    main()
